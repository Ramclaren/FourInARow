package com.example.fourinarow;
/**
 * Four in a row
 * @author Rion-Mark McLaren Jr.
 * @date 2/20/2022
 */
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class GameActivity extends AppCompatActivity {

    public static FourInARow FIRboard = new FourInARow();
    public boolean CFW = false;
    private String username;
    private List<Button> buttons;
    private static final int[] BUTTON_IDS = {
            R.id.button0,
            R.id.button1,
            R.id.button2,
            R.id.button3,
            R.id.button4,
            R.id.button5,
            R.id.button6,
            R.id.button7,
            R.id.button8,
            R.id.button9,
            R.id.button10,
            R.id.button11,
            R.id.button12,
            R.id.button13,
            R.id.button14,
            R.id.button15,
            R.id.button16,
            R.id.button17,
            R.id.button18,
            R.id.button19,
            R.id.button20,
            R.id.button21,
            R.id.button22,
            R.id.button23,
            R.id.button24,
            R.id.button25,
            R.id.button26,
            R.id.button27,
            R.id.button28,
            R.id.button29,
            R.id.button30,
            R.id.button31,
            R.id.button32,
            R.id.button33,
            R.id.button34,
            R.id.button35,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FIRboard.clearBoard();
        TextView winner = (TextView) findViewById(R.id.winner);
        Button restart = (Button) findViewById(R.id.restart);
        Button backToSplash = (Button) findViewById(R.id.backToSplash);
        username = getIntent().getStringExtra("usernameKey");

        buttons = new ArrayList<Button>();
        for(int id : BUTTON_IDS) {
            Button button = (Button)findViewById(id);
            button.setBackgroundResource(R.drawable.grey_chip);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (CFW = false && FIRboard.isEmpty(0) == true) {
                        FIRboard.setMove(1, 0);
                        button.setBackgroundResource(R.drawable.red_chip);

                        if (FIRboard.checkForWinner() == 1) {
                            winner.setText("You Won! Press restart to play again!");
                            CFW = true;
                        } else if (FIRboard.checkForWinner() == 3) {
                            winner.setText("You tied with the computer! Press restart to play again!");
                            CFW = true;
                        } else {
                            computerMove(winner);
                            winner.setText("It's your turn" + username + "!");
                        }
                    } else {
                        winner.setText("Try a different button!");
                    }
                }
            });
            buttons.add(button);
        }

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CFW = true) {
                    FIRboard.clearBoard();
                    CFW = false;
                    winner.setText("Thanks for playing again. Press a button to start!");
                    for (int id : BUTTON_IDS) {
                        Button button = (Button) findViewById(id);
                        button.setBackgroundResource(R.drawable.grey_chip);
                    }
                } else {
                    winner.setText("Wait for the game to finish! Press a button!");
                }
            }
        });
    }

    public void computerMove (TextView winner) {
        int move = FIRboard.getComputerMove();
        FIRboard.setMove(2, move);
        Button button = (Button)findViewById (BUTTON_IDS[move]);
        button.setBackgroundResource(R.drawable.yellow_chip);
        if (FIRboard.checkForWinner() == 0) {
            winner.setText("Awww the computer beat you... Press restart to play again!");
            CFW = true;
        } else if (FIRboard.checkForWinner() == 3) {
            winner.setText("You tied with the computer! Press restart to play again!");
            CFW = true;
        }
    }

    public void backToSplash(View view) {
        Intent intent = new Intent(this, SplashActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        CFW = savedInstanceState.getBoolean("CFW");
        username = savedInstanceState.getString("username");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean("CFW",CFW);
        outState.putString("username", username);
    }
}