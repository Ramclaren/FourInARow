package com.example.fourinarow;
/**
 * Four in a row
 * @author Rion-Mark McLaren Jr.
 * @date 2/20/2022
 */
public class FourInARow implements IGame{
    // The game board and the game status
    private static final int ROWS = 6, COLS = 6; // number of rows and columns
    private int[][] board = new int[ROWS][COLS]; // game board in 2D array


    @Override
    public void clearBoard() {
        // TODO Auto-generated method stub
        for (int row = 0; row < ROWS; ++row) {
            for (int col = 0; col < COLS; ++col) {
                board[row][col] = EMPTY;
            }
        }
    }

    @Override
    public void setMove(int player, int location) {
        // TODO Auto-generated method stub
        int col = location%6;
        int row = location/6;

        if (board[row][col] != EMPTY) {
            return;
        }
        board[row][col] = player;
    }

    @Override
    public int getComputerMove() {
        int cmove = (int) (Math.random() * (36));
        int col = cmove%6;
        int row = cmove/6;
        while (board[row][col] != EMPTY) {
            cmove = (int) (Math.random() * (36));
            col = cmove%6;
            row = cmove/6;
        }
        return cmove;
    }

    public boolean isEmpty(int location){
        int col = location%6;
        int row = location/6;
        if (board[row][col] == EMPTY) {
            return true;
        } else return false;
    }

    @Override
    public int checkForWinner() {
        int counter = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS-3; col++) {
                //Check for a vertical win
                if (board[row][col] == board[row][col+1] && board[row][col] == board[row][col+2] && board[row][col] == board[row][col+3]) {
                    if(board[row][col] == BLUE) {
                        return 1;
                    } else if (board[row][col] == RED){
                        return 0;
                    }
                    //Check for a horizontal win
                }
            }
        }
        for (int row = 0; row < ROWS-3; row++) {
            for (int col = 0; col < COLS; col++) {

                if (board[row][col] == board[row+1][col] && board[row][col] == board[row+2][col] && board[row][col] == board[row+3][col]) {
                    if(board[row][col] == BLUE) {
                        return 1;
                    } else if (board[row][col] == RED){
                        return 0;
                    }
                }
            }


            //Check for a Diagonal win
        }
        for (int row = 0; row < ROWS-3; row++) {
            for (int col = 0; col < COLS-3; col++) {
                if (row + 3 < ROWS && col + 3 < COLS && board[row][col] == board[row+1][col+1] && board[row][col] == board[row+2][col+2] && board[row][col] == board[row+3][col+3]) {
                    if(board[row][col] == BLUE) {
                        return 1;
                    } else if (board[row][col] == RED){
                        return 0;
                    }
                }
                if (board[row][col] != EMPTY) {
                    counter++;
                }

                if(counter == ROWS*COLS) {
                    return 3;
                }

            }
        }
        return 2;
    }
}
