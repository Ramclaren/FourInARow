package com.example.fourinarow;
/**
 * Four in a row
 * @author Rion-Mark McLaren Jr.
 * @date 2/20/2022
 */

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SplashActivity extends AppCompatActivity {
    String usernameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        EditText username = (EditText) findViewById(R.id.username);
        usernameText = username.getText().toString();
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("usernameKey",usernameText);
        startActivity(intent);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        usernameText = savedInstanceState.getString("username");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("username",usernameText);
    }
}